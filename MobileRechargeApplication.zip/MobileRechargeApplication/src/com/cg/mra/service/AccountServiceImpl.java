package com.cg.mra.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDAOImpl;
import com.cg.mra.dao.AccountDAO;
import com.cg.mra.dao.AccountDAOImpl;
import com.cg.mra.exception.MobileException;
import com.cg.mra.exception.MobileException;

public class AccountServiceImpl implements AccountService{
    AccountDAO dao;
    
    public AccountServiceImpl() {
        super();
        // TODO Auto-generated constructor stub
        dao = new AccountDAOImpl();
    }

    @Override
    public Account getAccountDetails(String mobileNo) {
        // TODO Auto-generated method stub
        return dao.getAccountDetails(mobileNo);
    }

    @Override
    public double rechargeAccount(String mobileno, double rechargeAmount) {
        // TODO Auto-generated method stub
        
        return rechargeAmount;
    }

    @Override
    public boolean validateMobileNo(String mobileNo)
            throws MobileException {
        // TODO Auto-generated method stub
        if(mobileNo == null)
            throw new MobileException("Null value found");
        Pattern p = Pattern.compile("[6789][0-9]{9}");
        Matcher m = p.matcher(mobileNo);
        return m.matches();
    }

    @Override
    public boolean validateRechargeAmount(Double rechargeAmount)
            throws MobileException {
        // TODO Auto-generated method stub
        if(rechargeAmount == null)
            throw new MobileException("Null value found");
        String ra = rechargeAmount.toString();
        return (ra.matches("\\d{2,9}\\.\\d{0,4}"));
    }

    
    
    
    


    

}
