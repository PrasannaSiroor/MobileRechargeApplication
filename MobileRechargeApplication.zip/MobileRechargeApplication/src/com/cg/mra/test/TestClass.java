package com.cg.mra.test;

import org.junit.Assert;
import org.junit.Test;

import com.cg.mra.exception.MobileException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;


public class TestClass {
    AccountService service = new AccountServiceImpl();
    boolean result;
    @Test(expected=MobileException.class)
    public void test_validateMobileNo_Null()throws MobileException{
        result = service.validateMobileNo(null);
        
    }
    
    @Test
    public void test_ValidateMobileNo_v1()throws MobileException{
        result = service.validateMobileNo("2345678910");
        Assert.assertEquals(false, result);
        
    }
    
    
    @Test
    public void test_ValidateMobileNo_v2()throws MobileException{
        result = service.validateMobileNo("796886858d");
        Assert.assertEquals(false, result);
        
    }
    
    @Test
    public void test_ValidateMobileNo_v3()throws MobileException{
        result = service.validateMobileNo("9877687477");
        Assert.assertEquals(true, result);
        
    }
    
    
    @Test(expected=MobileException.class)
    public void test_ValidateRechargeAmount_Null()throws MobileException{
        result = service.validateRechargeAmount(null);
        Assert.assertEquals(false, result);
    }
    
    
    @Test
    public void test_ValidateSalary_v1()throws MobileException{
        result = service.validateRechargeAmount(250.0);
        Assert.assertEquals(true, result);
    }
    
    @Test
    public void test_ValidateSalary_v2()throws MobileException{
        result = service.validateRechargeAmount(9000055.0);
        Assert.assertEquals(false, result);
    }
    
    @Test
    public void test_ValidateSalary_v3()throws MobileException{
        result = service.validateRechargeAmount(9.0);
        Assert.assertEquals(false, result);
    }

    @Test
    public void test_ValidateSalary_v4()throws MobileException{
        result = service.validateRechargeAmount(780.567);
        Assert.assertEquals(false, result);
    }
    

}

