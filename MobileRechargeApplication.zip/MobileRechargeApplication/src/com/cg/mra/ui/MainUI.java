package com.cg.mra.ui;
import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI{
public static void main(String args[]) {
    AccountService service = new AccountServiceImpl();
    Scanner sc = new Scanner(System.in); //declaring the scanner to access input from the keyboard
    Account account = new Account();
    int ch = 0; //intillizing the ch value to 0
   // int i =0;
    //Account account = new Account();
  
    do{
    System.out.println("\nEnter Choice :\n");
    System.out.println("1. Get Account Details :\n");
    System.out.println("2. Recharge Account :\n");
    System.out.println("3. Exit\n");
    ch = sc.nextInt();
    switch(ch) {
    case 1:
        System.out.println("Enter Mobile No:");
        String mobileno = sc.next();
        //Account service = new AccountServiceImpl();
        account = service.getAccountDetails(mobileno);
        if(account == null)
            System.out.println("ERROR: Given Account Id Does Not Exists");
        //if the entered mobile number does not exist in the list it will display an error
        else{
            
                
                System.out.println("Your Current Balance is Rs." +account.getAccountBalance()); //prints the current accountBalance
            }
        
            break;
    case 2:
        System.out.println("Enter Mobile No:");
        mobileno = sc.next();
        System.out.println("Enter Recharge Amount");
        double rechargeAmount = sc.nextDouble();
        account = service.getAccountDetails(mobileno);
        double recharge = service.rechargeAccount(mobileno, rechargeAmount);
        if(account == null){
            System.out.println("ERROR: Cannot Recharge Account as Given Mobile No Does Not Exists");
        }
        else{
            account.setAccountBalance(account.getAccountBalance()+recharge); //if the mobile get recharged successsfull 
            System.out.println("Your Account Recharged Successfully");
            System.out.println("Hello "+account.getCustomerName() + ","+"Available Balance is "+account.getAccountBalance());
            
        }
        break;
    case 3:  System.out.println("exit");
        exit(0);
       break;
        
        }
    
        
    }while(ch!=3); //end do while loop
    
}

private static void exit(int i) {
	// TODO Auto-generated method stub
	
} // it calls to the case 3 , exit(0) 



}//end class




